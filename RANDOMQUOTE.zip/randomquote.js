var string1 = "This is the first quote";
var string2 = "This is the second quote";
var string3 = "This is the third quote";
var newArray = new Array(string1, string2,  string3);
function getQuote() {
  var rndNum = Math.floor(Math.random() * (newArray.length - 1 + 1)) + 1;
  var getQuoteParentElement = document.getElementById("appendQuote");
  var pickQuote = document.createElement("p");
  console.log(string1);
  console.log(newArray[2]);
  console.log(rndNum);
  pickQuote.innerHTML = newArray[rndNum];
  getQuoteParentElement.appendChild(pickQuote);
}
